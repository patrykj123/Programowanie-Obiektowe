#ifndef CTRIANGLE_H
#define CTRIANGLE_H

#include <windows.h>
#include "CFilledShape.h"

class CTriangle : public CFilledShape
{
private:
	//Tablica wierzcho�k�w tr�jk�ta.
    POINT mVertices[3];

    //Metoda prywatna s�u��ca do przeliczenia wierzcho�k�w na podstawie aktualnego prostok�ta opisanego na figurze (w�a�ciwo�� BoundingRect).
    void updateVertices();

protected:
    //Metoda wykonuj�ca rysowanie (bez konieczno�ci obs�ugi pi�r i p�dzli).
    virtual void doPaint(HDC hdc);

    //Wyzwalacz (trigger) wywo�ywany tu� po zmianie w�a�ciwo�ci BoundingRect.
    //Klasa CTriangle musi zareagowa� na zmian� w�a�ciwo�ci BoundingRect aktualizacj� wierzcho�k�w tr�jk�ta.
    virtual void afterBoundingRectChange();

public:
    //**** Constructors & destructor ****
	CTriangle();
};

#endif // CTRIANGLE_H
