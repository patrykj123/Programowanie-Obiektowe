#include "CTriangle.h"

//**** Private methods ****

void CTriangle::updateVertices()
{
	const RECT& boundingRect = getBoundingRect();

    mVertices[0].x = boundingRect.left;
    mVertices[0].y = boundingRect.bottom;
    mVertices[1].x = (boundingRect.left + boundingRect.right) / 2;
    mVertices[1].y = boundingRect.top;
    mVertices[2].x = boundingRect.right;
    mVertices[2].y = boundingRect.bottom;
}

//********** Protected methods ***********
void CTriangle::doPaint(HDC hdc)
{
    Polygon(hdc, mVertices, 3);
}

void CTriangle::afterBoundingRectChange()
{
    updateVertices();
}

//**** Constructors & destructor ****
CTriangle::CTriangle()
{
	for(int i=0; i<3; i++)
	{
        mVertices[i].x = 0;
        mVertices[i].y = 0;
	}
}
